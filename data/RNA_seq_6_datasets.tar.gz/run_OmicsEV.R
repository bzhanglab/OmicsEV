library(OmicsEV)
run_omics_evaluation(data_dir = "datasets/",
                     sample_list = "sample_list.tsv",
                     x2 = "protein.tsv",
                     cpu=0,
                     data_type="gene",
                     ml_class="sample_ml.tsv") 
