library(OmicsEV)
run_omics_evaluation(data_dir = "datasets/",
					 sample_list = "sample_list.tsv",
					 x2 = "protein.tsv",
					 x2_label = "Protein",
					 cpu=0,
					 use_existing_data=TRUE,
					 data_type="gene",
					 class_for_ml="sample_ml.tsv")
