library(OmicsEV)
run_omics_evaluation(data_dir = "datasets_75/",
                     sample_list = "sample_list_v2.tsv",
                     x2 = "rna.tsv",
                     cpu=0,
                     use_existing_data=TRUE,
                     data_type="gene",
                     class_for_ml=c("LumA","LumB"))
